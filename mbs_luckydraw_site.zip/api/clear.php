<?php
$base = dirname(__DIR__) . DIRECTORY_SEPARATOR . 'data';
@unlink($base . '/entries.jsonl');
@unlink($base . '/entries.csv');
header('Content-Type: application/json');
echo json_encode(['ok'=>true]);
