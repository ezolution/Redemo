<?php
header('Content-Type: application/json');
$raw = file_get_contents('php://input');
$payload = json_decode($raw, true);
function bad($m){ http_response_code(400); echo json_encode(['ok'=>false,'error'=>$m]); exit; }
if(!$payload){ bad('Invalid JSON'); }
$fullName = trim($payload['fullName'] ?? '');
$email = trim($payload['email'] ?? '');
$department = trim($payload['department'] ?? '');
$gift = trim($payload['giftChoice'] ?? '');
if($fullName === '' || $email === '' || $department === '' || $gift === ''){ bad('Missing fields'); }
if(!filter_var($email, FILTER_VALIDATE_EMAIL)){ bad('Invalid email'); }
$ts = date('c');
$entry = ['ts'=>$ts,'fullName'=>$fullName,'email'=>$email,'department'=>$department,'giftChoice'=>$gift];
$base = dirname(__DIR__) . DIRECTORY_SEPARATOR . 'data';
@mkdir($base, 0755, true);
file_put_contents($base . '/entries.jsonl', json_encode($entry) . PHP_EOL, FILE_APPEND | LOCK_EX);
$csvPath = $base . '/entries.csv';
$headers = ['timestamp','fullName','email','department','giftChoice'];
if(!file_exists($csvPath)){ file_put_contents($csvPath, implode(',', $headers) . PHP_EOL, FILE_APPEND | LOCK_EX); }
$csvRow = [$ts,'"' . str_replace('"','""',$fullName) . '"','"' . str_replace('"','""',$email) . '"','"' . str_replace('"','""',$department) . '"','"' . str_replace('"','""',$gift) . '"'];
file_put_contents($csvPath, implode(',', $csvRow) . PHP_EOL, FILE_APPEND | LOCK_EX);
echo json_encode(['ok'=>true]);
