<?php
header('Content-Type: application/json');
$base = dirname(__DIR__) . DIRECTORY_SEPARATOR . 'data';
$visFile = $base . '/visitors.count';
$visitors = 0;
if(file_exists($visFile)){ $visitors = (int)trim(file_get_contents($visFile)); }
$rows = [];
$entriesFile = $base . '/entries.jsonl';
if(file_exists($entriesFile)){
  $fh = fopen($entriesFile, 'r');
  if($fh){
    while(($line = fgets($fh)) !== false){
      $line = trim($line);
      if($line){ $obj = json_decode($line, true); if($obj) $rows[] = $obj; }
    }
    fclose($fh);
  }
}
echo json_encode([ 'visitors' => $visitors, 'rows' => $rows ]);
